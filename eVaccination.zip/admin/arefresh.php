<?php
 // fetch details
$result = mysqli_query($conn, "SELECT * FROM `admin` WHERE aphone = '".$aphone. "'");
if ($row = mysqli_fetch_array($result)) {
    $aname=$row['aname'];
} 
?>
