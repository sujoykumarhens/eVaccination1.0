<?php 
if (isset($_POST['resetData'])) {
    $newname = mysqli_real_escape_string($conn, $_POST['newname']);
    $newpassword = mysqli_real_escape_string($conn, $_POST['newpassword']);
    // $newpassword = hash("sha256", $newpassword);
    $sql = "UPDATE `admin` SET `aname`='".$newname."', `apassword`='".$newpassword."'   WHERE `aphone`='".$aphone."'";
    if (mysqli_query($conn, $sql)) {
        echo "<meta http-equiv='refresh' content='0'>";
        echo "<script>swal('Successful','You have changed your details successfully','success');</script>";
    } else {
        echo "<script>swal('Error','Sorry some  error occured','error');</script> ";
    }
}
?>
<h4 class="text">Admin Dashboard</h4>

<div class="jumbotron shadow-sm">
    <div class="container-fluid">
        <div class="d-flex justify-content-between">
            <div>
                <h2 class="font-weight-bold">Update Your Informations</h2>
                <form method="POST" enctype="multipart/form-data" class="needs-validation" novalidate>
                    <div class="form-group">
                        <input type="text" class="fadeIn first" pattern="[a-zA-Z\s]+" title="Enter a valid name" name="newname" id="name" placeholder="Full Name*" required autofocus>
                        <div class="invalid-feedback">
                            Please enter your name.
                        </div>
                    </div>
                    <div class="form-group">
                        <input type="password" class="fadeIn fourth" name="newpassword"  id="password" pattern="(?=.*\d)(?=.*[a-z])(?=.*[A-Z]).{8,}" title="Must contain at least one number and one uppercase and lowercase letter, and at least 8 or more characters without any special character" placeholder="New Password*" required>
                        <div class="invalid-feedback">
                            Please enter password.
                        </div>
                    </div>
                    <button type="submit" name="resetData" class="btn btn-danger">Update</button>
                </form>
            </div>
            <div class="logobg d-none d-sm-none d-md-block"></div>
        </div>
    </div>
</div>