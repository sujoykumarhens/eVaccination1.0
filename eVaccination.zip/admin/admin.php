<?php
session_start();
include("../assets/header/header.php");
include("../assets/links/loader.php");
// Check user login or not
if (!isset($_SESSION['aphone'])) {
    header('Location: ../registration/login.php');
}
// logout
if (isset($_POST['but_logout'])) {
    unset($_SESSION["aphone"]);
    session_destroy();
    header('Location: ../registration/login.php');
}
$aphone = $_SESSION['aphone'];
include("../config/db.php");
// fetch details
$result = mysqli_query($conn, "SELECT * FROM `admin` WHERE aphone = '" . $aphone . "'");
if ($row = mysqli_fetch_array($result)) {
    if ($row > 0) {
        $aname = $row['aname'];
    }
}
?>
<script src="../assets/js/sweetalert.min.js"></script>
<link rel="stylesheet" type="text/css" href="../assets/css/patient.css" />
<!-- dashboard start -->
<div class="sidebar">
    <div class="logo-details">
        <img src="../assets/images/logo.svg" height="30" width="" class="icon rounded-circle" />&nbsp;
        <div class="logo_name">eVaccination</div>
        <i class='bx bx-menu' id="btn"></i>
    </div>
    <ul class="nav-list nav nav-pills">
        <li class="active">
            <a href="#dashboard" data-toggle="pill">
                <i class='bx bx-grid-alt'></i>
                <span class="links_name">Dashboard</span>
            </a>
            <span class="tooltip">Dashboard</span>
        </li>
        <li>
            <a href="#vaccine" data-toggle="pill">
                <i class='bx bx-shield-alt-2'></i>
                <span class="links_name">Vaccine</span>
            </a>
            <span class="tooltip">Vaccine</span>
        </li>
        <li>
            <a href="#hospital" data-toggle="pill">
                <i class='bx bxs-clinic'></i>
                <span class="links_name">Hospital</span>
            </a>
            <span class="tooltip">Hospital</span>
        </li>
        <li>
            <a href="#setting" data-toggle="pill">
                <i class='bx bx-cog'></i>
                <span class="links_name">Setting</span>
            </a>
            <span class="tooltip">Setting</span>
        </li>
        <li class="profile">
            <div class="profile-details">
                <!--<img src="profile.jpg" alt="profileImg">-->
                <div class="name_job">
                    <div class="name"><?php echo $aname; ?></div>
                    <div class="job">Admin</div>
                </div>
            </div>
            <form method="POST"><button type="submit" name="but_logout"><i class='bx bx-log-out' id="log_out"></i></button></form>
        </li>
    </ul>
</div>
<section class="home-section tab-content">
    <div class="tab-pane active" id="dashboard">
        <?php
        include("aDashboard.php");
        ?>
    </div>
    <div class="tab-pane" id="vaccine">
        <?php
        include("aVaccine.php");
        ?>
    </div>
    <div class="tab-pane" id="hospital">
        <?php
        include("aHospital.php");
        ?>
    </div>
    <div class="tab-pane" id="setting">
        <?php
        include("aSetting.php");
        ?>
    </div>
</section>
<!-- Modal for slot booking -->
<div class="modal fade" id="newBooking" tabindex="-1" aria-labelledby="newBooking" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content border border-danger shadow-sm">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLabel">Book your slot now</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <form>
                    <div class="form-group">
                        <label for="hospitalName">Hospital Name</label>
                        <input type="text" class="form-control" readonly name="hospitalName" id="hospitalName" placeholder="Hospital">
                    </div>
                    <div class="form-row">
                        <div class="form-group col-lg">
                            <label for="bookingDate">Select your date slot</label>
                            <input type="text" class="form-control" id="bookingDate" name="bookingDate" placeholder="Another input placeholder">
                        </div>
                        <div class="form-group col-lg">
                            <label for="bookingDate">Select your time slot</label>
                            <div class="form-check">
                                <input class="form-check-input" type="radio" name="timeSlot" id="10_11" value="10_11">
                                <label class="form-check-label" for="10_11">10:00-11:00</label>
                            </div>
                            <div class="form-check">
                                <input class="form-check-input" type="radio" name="timeSlot" id="11_12" value="11_12">
                                <label class="form-check-label" for="11_12">11:00-12:00</label>
                            </div>
                            <div class="form-check">
                                <input class="form-check-input" type="radio" name="timeSlot" id="13_14" value="13_14">
                                <label class="form-check-label" for="13_14">13:00-14:00</label>
                            </div>
                        </div>
                    </div>
                </form>
            </div>
            <div class="modal-footer">
                <button type="submit" class="btn btn-danger">Book now</button>
            </div>
        </div>
    </div>
</div>
<?php include("../assets/footer/footer.php"); ?>
<script type="text/javascript" src="../assets/js/patient.js"></script>
<?php $conn->close(); ?>