<?php
require '../config/db.php';
if (isset($_GET['requestid'])) {
    $sql4 = mysqli_query($conn, "SELECT * FROM `hospital` WHERE `requestid`='" . $_GET['requestid'] . "'");
    while($row = mysqli_fetch_array($sql4)) {
        $requestamount=$row['requestamount'];
        $hvstock=$row['hvstock']+$row['requestamount'];
        $requeststatus="closed";
        $vaccinereduce = mysqli_query($conn, "SELECT * FROM `hospital` INNER JOIN `vaccine` ON hospital.requestvid=vaccine.vid WHERE `requestid`='" . $_GET['requestid'] . "'");
        if($rowx = mysqli_fetch_array($vaccinereduce)) {
            $vstock=$rowx['vstock'];
            $vid=$rowx['vid'];
            $vstock=$vstock - $requestamount;
            $updatevaccinestock = "UPDATE `vaccine` SET `vstock`='".$vstock."' WHERE `vid`='xx'";
            if (mysqli_query($conn, $updatevaccinestock)) {
                $requestamount=0;
                $updatevaccine = "UPDATE `hospital` SET `hvstock`='" . $hvstock . "',`requeststatus`='".$requeststatus."',`requestamount`='".$requestamount."' WHERE `requestid`='" . $_GET['requestid'] . "'";
                if (mysqli_query($conn, $updatevaccine)) {
                    echo "<meta http-equiv='refresh' content='0'>";
                    echo "<script>alert('Request accepted');</script>";
                    echo "<script>window.location.href = 'admin.php';</script>";
                }
                else {
                    echo "<script>alert('Error');</script> ";
                    echo "<script>window.location.href = 'admin.php';</script>";
                }
            }
        }

    }
    
}
?>