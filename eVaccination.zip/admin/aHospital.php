<h4 class="text">Admin Dashboard</h4>

<div class="jumbotron shadow-sm">
    <h4 class="font-weight-bold">Requested for allocation</h4>
    <div class="container-fluid requestVaccinationAlert">
        <?php
        $vaccinerequest = mysqli_query($conn, "SELECT * FROM `hospital` WHERE `requeststatus`='active'");
        while ($row = mysqli_fetch_array($vaccinerequest)) {
            $requestid = $row['requestid'];
            echo "<div class='alert alert-danger alert-dismissible fade show' role='alert'>";
            echo "<a href='request.php?requestid=$requestid' class='btn text-decoration-none btn-sm btn-outline-danger'><i class='bx bx-check-double'></i> Allocate</a>&emsp13;<strong> Hospital :'" . $row['hname'] . "', ID : '" . $row['hid'] . "'</strong> has requested for <strong>'" . $row['requestamount'] . "'</strong> Vaccines.";
            echo "<button type='button' class='close' data-dismiss='alert' aria-label='Close'><span aria-hidden='true'>&times;</span></button></div>";
        }
        ?>
    </div>
</div>
<div class="jumbotron shadow-sm">
    <div class="container-fluid">
        <h4 class="font-weight-bold">Hospital Stock Report</h4>
        <table class="table  border border-danger" id="table_print">
            <thead class="thead">
                <tr class="bg-danger text-white">
                    <th scope="col">#ID</th>
                    <th scope="col">Hospital Name</th>
                    <th scope="col">Hospital Address</th>
                    <th scope="col">Contact No</th>
                    <th scope="col">Current Stock</th>
                </tr>
            </thead>
            <tbody>
                <?php
                $sql3 = mysqli_query($conn, "SELECT * FROM `hospital`");
                while ($row = mysqli_fetch_array($sql3)) {
                    echo "<tr><td>" . $row["hid"] . "</td><td>" . $row["hname"] . "</td><td>" . $row["hcity"] . "</td><td>" . $row["hphone"] . "</td><td>" . $row["hvstock"] . "</td></tr>";
                }
                ?>
            </tbody>
        </table>
    </div>
</div>