<?php
require '../config/db.php';
if (isset($_GET['vid'])) {
    $sql = "DELETE FROM `vaccine` WHERE vid='".$_GET['vid']."'";
    if (mysqli_query($conn, $sql)) {
        echo "<script>alert('Vaccine removed successfully');</script>";
        echo "<script>window.location.href = 'admin.php';</script>";
        die;
    } else {
        echo "<script>alert('Sorry some  error occured');</script> ";
        echo "<script>window.location.href = 'admin.php';</script>";
        die;
    }
}
?>