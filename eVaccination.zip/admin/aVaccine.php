<?php
if (isset($_POST['addvaccine'])) {
    $vid = mysqli_real_escape_string($conn, $_POST['vid']);
    $vname = mysqli_real_escape_string($conn, $_POST['vname']);
    $vdetails = mysqli_real_escape_string($conn, $_POST['vdetails']);
    $vstock = mysqli_real_escape_string($conn, $_POST['vstock']);
    $sql = "INSERT INTO `vaccine`(`vid`, `vname`, `vdetails`, `vstock`) VALUES ('" . $vid . "','" . $vname . "','" . $vdetails . "','" . $vstock . "')";
    if (mysqli_query($conn, $sql)) {
        echo "<meta http-equiv='refresh' content='0'>";
        echo "<script>swal('Vaccine added successfully','The vaccine added sucessfully','success');</script>";
    } else {
        echo "<script>swal('Error','Sorry some  error occured','error');</script> ";
    }
}
if (isset($_POST['uvstock'])) {
    $vid = mysqli_real_escape_string($conn, $_POST['nvid']);
    $vstock = mysqli_real_escape_string($conn, $_POST['nvstocks']);
    $count = mysqli_query($conn, "SELECT `vstock` FROM `vaccine` WHERE `vid`='" . $vid . "'");
    while ($row = mysqli_fetch_assoc($count)) {
        $vstock += $row['vstock'];
    }
    $query2 = mysqli_query($conn, "SELECT `vstock` FROM `vaccine` WHERE `vid`='" . $vid . "'");
    if ($row = mysqli_fetch_assoc($query2)) {
        $sql2 = "UPDATE `vaccine` SET `vstock`='" . $vstock . "' WHERE `vid`='" . $vid . "'";
        if (mysqli_query($conn, $sql2)) {
            echo "<meta http-equiv='refresh' content='0'>";
            echo "<script>swal('Stock updated successfully','The vaccine added sucessfully','success');</script>";
        }
    } else {
        echo "<script>swal('Error','No vaccine id found','error');</script> ";;
    }
}
?>

<h4 class="text">Admin Dashboard</h4>

<div class="jumbotron shadow-sm">
    <div class="container-fluid">
        <h4 class="font-weight-bold">Add/Update Vaccines</h4>
        <ul class="nav nav-pills mb-3 addUpdateVvaccine" id="pills-tab" role="tablist">
            <li class="nav-item" role="presentation">
                <a class="nav-link  active" id="pills-addNew-tab" data-toggle="pill" href="#pills-addNew" role="tab" aria-controls="pills-addNew" aria-selected="true"><i class='bx bx-plus'></i> Add New Vaccine</a>
            </li>
            <li class="nav-item" role="presentation">
                <a class="nav-link" id="pills-updateStock-tab" data-toggle="pill" href="#pills-updateStock" role="tab" aria-controls="pills-updateStock" aria-selected="false"><i class='bx bx-refresh'></i> Update Stock</a>
            </li>
        </ul>
        <div class="tab-content" id="pills-tabContent">
            <div class="tab-pane fade show active" id="pills-addNew" role="tabpanel" aria-labelledby="pills-addNew-tab">
                <form method="POST" enctype="multipart/form-data" class="needs-validation" novalidate>
                    <div class="form-row">
                        <div class="col-md-6 mb-3">
                            <label for="vaccineName">Vaccine Name</label>
                            <input type="text" class="form-control" name="vname" id="vaccineName" required>
                            <div class="valid-feedback">
                                Looks good!
                            </div>
                            <div class="invalid-feedback">
                                Please provide a valid input.
                            </div>
                        </div>
                        <div class="col-md-6 mb-3">
                            <label for="vaccineID">Vaccine ID</label>
                            <input type="text" class="form-control" name="vid" id="vaccineID" required>
                            <div class="valid-feedback">
                                Looks good!
                            </div>
                            <div class="invalid-feedback">
                                Please provide a valid input.
                            </div>
                        </div>
                    </div>
                    <div class="form-row">
                        <div class="col-md-6 mb-3">
                            <label for="vaccineDetails">Vaccine Details</label>
                            <input type="text" class="form-control" name="vdetails" id="vaccineDetails" required>
                            <div class="valid-feedback">
                                Looks good!
                            </div>
                            <div class="invalid-feedback">
                                Please provide a valid input.
                            </div>
                        </div>
                        <div class="col-md-3 mb-3">
                            <label for="stockAmount">Stock Amount</label>
                            <input type="text" class="form-control" name="vstock" id="stockAmount" required>
                            <div class="invalid-feedback">
                                Please provide a valid input.
                            </div>
                        </div>
                    </div>
                    <button class="p-2 pl-4 pr-4 border-0 btn-danger" name="addvaccine" type="submit">Submit form</button>
                </form>
            </div>
            <div class="tab-pane fade" id="pills-updateStock" role="tabpanel" aria-labelledby="pills-updateStock-tab">
                <form class="needs-validation" method="POST" enctype="multipart/form-data" novalidate>
                    <div class="form-row">
                        <div class="col-md-4 mb-3">
                            <label for="vaccineID">Vaccine ID</label>
                            <input type="text" class="form-control" name="nvid" id="vaccineID" required>
                            <div class="valid-feedback">
                                Looks good!
                            </div>
                            <div class="invalid-feedback">
                                Please provide a valid input.
                            </div>
                        </div>
                        <div class="col-md-3 mb-3">
                            <label for="stockAmount">Stock Amount</label>
                            <input type="text" class="form-control" name="nvstocks" id="stockAmount" required>
                            <div class="invalid-feedback">
                                Please provide a valid input.
                            </div>
                        </div>
                    </div>
                    <button class="p-2 pl-4 pr-4 border-0 btn-danger" name="uvstock" type="submit">Submit form</button>
                </form>
            </div>
            <script>
                // Example starter JavaScript for disabling form submissions if there are invalid fields
                (function() {
                    'use strict';
                    window.addEventListener('load', function() {
                        // Fetch all the forms we want to apply custom Bootstrap validation styles to
                        var forms = document.getElementsByClassName('needs-validation');
                        // Loop over them and prevent submission
                        var validation = Array.prototype.filter.call(forms, function(form) {
                            form.addEventListener('submit', function(event) {
                                if (form.checkValidity() === false) {
                                    event.preventDefault();
                                    event.stopPropagation();
                                }
                                form.classList.add('was-validated');
                            }, false);
                        });
                    }, false);
                })();
            </script>
        </div>
    </div>
</div>

<div class="jumbotron shadow-sm">
    <div class="container-fluid">
        <h4 class="font-weight-bold">Vaccines List</h4>
        <table class="table border border-danger">
            <thead>
                <tr class="bg-danger text-white">
                    <th scope="col">#ID</th>
                    <th scope="col">Vaccine Name</th>
                    <th scope="col">Available Stock</th>
                    <th scope="col">Action</th>
                </tr>
            </thead>
            <tbody>
                <?php
                $sql3 = mysqli_query($conn, "SELECT * FROM `vaccine`");
                while ($row = mysqli_fetch_array($sql3)) {
                    echo "<tr><td>" . $row["vid"] . "</td><td>" . $row["vname"] . "</td><td>" . $row["vstock"] . "</td><td><a href='delete.php?vid=" . $row['vid'] . "' class='text-danger border bg-light text-decoration-none p-2'><i class='bx bxs-trash'></i> Delete</a></td></tr>";
                }
                ?>
            </tbody>
        </table>
    </div>
</div>