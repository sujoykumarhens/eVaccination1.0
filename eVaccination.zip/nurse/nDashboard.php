<h4 class="text">Nurse Dashboard</h4>
<div class="row">
    <div class="col-lg">
        <div class="jumbotron shadow-sm">
            <div class="container-fluid">
                <div class="d-flex justify-content-between">
                    <div>
                        <h1 class="mb-3"><strong id="textColor">Sunita Khan</strong></h1>
                        <p class="lead"><i class='bx bx-hash'></i>adding_extra_life!</p>
                        <div class="card" style="width: 22rem;">
                            <div class="card-body">
                                <h5 class="font-weight-bold m-0">
                                    <i class='bx bxs-basket'></i> Current Total Stock <strong id="textColor">100</strong>&nbsp;
                                    <a href="#" class="text-decoration-none text-danger has-spiner"><i class="bx  bx-border-circle bx-refresh"></i></a>
                                </h5>
                            </div>
                        </div>
                    </div>
                    <div class="backgoundLogo"></div>
                </div>
            </div>
        </div>
    </div>
    <div class="col-lg-3">
        <div class="card mb-4">
            <div class="card-body">
                <h5 class="card-title font-weight-bold"><i class='bx bxs-calendar-event'></i> <span id="currentDate"></span></h5>
                <p class="text-danger mb-0"><i class='bx bxs-time-five bx-spin'></i>&nbsp;<span id="MyClockDisplay" class="clock" onload="showTime()"></span></p>
            </div>
        </div>
        <div class="card-deck">
            <div class="card">
                <div class="card-body text-center">
                    <h5 class="card-title font-weight-bold">Total Patient</h5>
                    <h1 class="card-text mb-0 font-weight-bold" id="textColor">15
                        <a href="#" class="text-decoration-none text-danger has-spiner"><i class="bx bx-sm bx-border-circle bx-refresh"></i></a>
                    </h1>
                </div>
            </div>
            <div class="card">
                <div class="card-body text-center">
                    <h5 class="card-title font-weight-bold">Total Vaccine</h5>
                    <h1 class="card-text mb-0 font-weight-bold" id="textColor">15
                        <a href="#" class="text-decoration-none text-danger has-spiner"><i class="bx bx-sm bx-border-circle bx-refresh"></i></a>

                    </h1>
                </div>
            </div>
        </div>
    </div>
</div>

<div class="row">
    <div class="col-lg">
        <div class="jumbotron shadow-sm">
            <div class="container-fluid">
                <h4 class="font-weight-bold">New vaccination</h4>
                <form class="needs-validation" novalidate>
                    <div class="form-row">
                        <div class="col-md-4 mb-3">
                            <label for="vaccineID">Vaccine ID</label>
                            <input type="text" class="form-control" id="vaccineID" required>
                            <div class="valid-feedback">
                                Looks good!
                            </div>
                            <div class="invalid-feedback">
                                Please provide a valid input.
                            </div>
                        </div>
                        <div class="col-md-3 mb-3">
                            <label for="pID">Patient ID</label>
                            <input type="text" class="form-control" id="pID" required>
                            <div class="invalid-feedback">
                                Please provide a valid input.
                            </div>
                        </div>
                        <div class="col-md-5 mb-3">
                            <label for="pName">Patient Name</label>
                            <input type="text" class="form-control" id="pName" disabled required>
                        </div>
                    </div>
                    <button class="p-2 pl-4 pr-4 border-0 btn-danger" type="submit">Submit form</button>
                </form>
                <script>
                    // Example starter JavaScript for disabling form submissions if there are invalid fields
                    (function() {
                        'use strict';
                        window.addEventListener('load', function() {
                            // Fetch all the forms we want to apply custom Bootstrap validation styles to
                            var forms = document.getElementsByClassName('needs-validation');
                            // Loop over them and prevent submission
                            var validation = Array.prototype.filter.call(forms, function(form) {
                                form.addEventListener('submit', function(event) {
                                    if (form.checkValidity() === false) {
                                        event.preventDefault();
                                        event.stopPropagation();
                                    }
                                    form.classList.add('was-validated');
                                }, false);
                            });
                        }, false);
                    })();
                </script>
            </div>
        </div>
    </div>
    <div class="col-lg-7">
        <div class="jumbotron shadow-sm">
            <div class="container-fluid">
                <h4 class="font-weight-bold">Vaccines List</h4>
                <table class="table border border-danger">
                    <thead>
                        <tr class="bg-danger text-white">
                            <th scope="col">#ID</th>
                            <th scope="col">Patient Name</th>
                            <th scope="col">Current Status</th>
                            <th scope="col">Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        <tr>
                            <th scope="row">1</th>
                            <td>164ASD</td>
                            <td>5005</td>
                            <td>
                                <button data-toggle="modal" data-target="#verifyPatient" class="border text-decoration-none text-danger border-danger p-1"><i class='bx bxs-user-badge'></i> View</button>
                            </td>
                        </tr>
                        <tr>
                            <th scope="row">1</th>
                            <td>164ASD</td>
                            <td>5005</td>
                            <td>
                                <button data-toggle="modal" data-target="#verifyPatient" class="border text-decoration-none text-danger border-danger p-1"><i class='bx bxs-user-badge'></i> View</button>
                            </td>
                        </tr>
                        <tr>
                            <th scope="row">1</th>
                            <td>164ASD</td>
                            <td>5005</td>
                            <td>
                                <button data-toggle="modal" data-target="#verifyPatient" class="border text-decoration-none text-danger border-danger p-1"><i class='bx bxs-user-badge'></i> View</button>
                            </td>
                        </tr>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>