<h4 class="text">Nurse Dashboard</h4>

<div class="jumbotron shadow-sm">
    <div class="container-fluid">
        <div class="d-flex justify-content-between">
            <div>
                <h2 class="font-weight-bold">Update Your Informations</h2>
                <form>
                    <div class="form-group">
                        <input type="text" class="fadeIn first" pattern="[a-zA-Z\s]+" title="Enter a valid name" name="name" id="name" placeholder="Full Name*" required autofocus>
                    </div>
                    <div class="form-group">
                        <input type="password" class="fadeIn fourth" id="password" pattern="(?=.*\d)(?=.*[a-z])(?=.*[A-Z]).{8,}" title="Must contain at least one number and one uppercase and lowercase letter, and at least 8 or more characters without any special character" name="New password" placeholder="New Password*" onkeyup="passcheck();" required>
                    </div>
                    <button type="submit" class="btn btn-danger">Update</button>
                </form>
            </div>
            <div class="logobg d-none d-sm-none d-md-block"></div>
        </div>
    </div>
</div>