<?php include ("assets/links/loader.php"); ?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta http-equiv="content-type" content="text/html; charset=UTF-8">
    <meta charset="utf-8">
    <meta name="theme-color" content="#000066">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <link rel="icon" href="assets/images/logo.svg">
    <title>eVaccination</title>
    <link rel="stylesheet" type="text/css" href="assets/bootstrap/css/bootstrap.min.css">
    <script src="assets/css/fontawesome.min.js" crossorigin="anonymous"></script>
    <link rel="stylesheet" type="text/css" href="assets/css/index.css">
</head>

<body>
    <div class="container d-flex h-100 p-3 mx-auto flex-column">
        <header class="masthead mb-auto">
            <div class="inner">
                <span class="logo">
                    <img src="assets/images/logo.svg" height="50" width="50">
                    <!-- <i class="fas fa-syringe fa-3x"></i> -->
                </span>
                <h3 class="masthead-brand">eVaccination Management System</h3>
                <nav class="nav nav-masthead justify-content-center">
                    <a class="nav-link active" href="#"><i class="fas fa-laptop-house"></i> Home</a>
                    <a class="nav-link" href="registration/signup.php"><i class="fas fa-user-plus"></i> Register</a>
                    <a class="nav-link" href="registration/login.php"><i class="fas fa-sign-in-alt"></i> Signin</a>
                </nav>
            </div>
        </header>
        <div id="myCarousel" class="row carousel slide carousel-fade" data-ride="carousel">
            <div class="carousel-inner">
                <div class="carousel-item active">
                    <div class="mask flex-center">
                        <div class="container">
                            <div class="row align-items-center">
                                <div class="col-md-7 col-12 order-md-1 order-2">
                                    <h4>Digital education for<br>
                                        all the students !</h4>
                                    <p>Our vision is to be the source for learning on the<br /> internet available from anywhere and without charge.<br /> It has a huge amount of books and video sources<br /> which will surely amaze you !</p>
                                    <a href="others/description.php" target="_blank" class="btn btn-lg btn-secondary">Know more
                                        <i class="fas fa-external-link-alt"></i></a>
                                </div>
                                <div class="col-md-5 col-12 order-md-2 order-1"><img src="assets/images/getting-vaccine.jpg" class="mx-auto" alt="slide"></div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="carousel-item">
                    <div class="mask flex-center">
                        <div class="container">
                            <div class="row align-items-center">
                                <div class="col-md-7 col-12 order-md-1 order-2">
                                    <h4>Ease to manage<br> the office works !</h4>
                                    <p>It includes each and every features like managing stock,<br> manipulate students data, give notices, helding class tests<br /> and much more !</p>
                                    <a href="others/description.php" target="_blank" class="btn btn-lg btn-secondary">Know more
                                        <i class="fas fa-external-link-alt"></i></a>
                                </div>
                                <div class="col-md-5 col-12 order-md-2 order-1"><img src="assets/images/getting-vaccine1.webp" class="mx-auto" alt="slide"></div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="carousel-item">
                    <div class="mask flex-center">
                        <div class="container">
                            <div class="row align-items-center">
                                <div class="col-md-7 col-12 order-md-1 order-2">
                                    <h4>Share your needs<br /> in just one click !</h4>
                                    <p>This is a one stop solution to<br /> request authority what you want.<br /> It is as simple as that !</p>
                                    <a href="others/description.php" target="_blank" class="btn btn-lg btn-secondary">Know more
                                        <i class="fas fa-external-link-alt"></i></a>
                                </div>
                                <div class="col-md-5 col-12 order-md-2 order-1"><img src="assets/images/indeximage1.png" class="mx-auto" alt="slide"></div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="carousel-item">
                    <div class="mask flex-center">
                        <div class="container">
                            <div class="row align-items-center">
                                <div class="col-md-7 col-12 order-md-1 order-2">
                                    <h4>Share your creative<br /> ideas to the teachers !</h4>
                                    <p>Be more creative and professional<br> with the helps of your teacher !</p>
                                    <a href="others/description.php" target="_blank" class="btn btn-lg btn-secondary">Know more
                                        <i class="fas fa-external-link-alt"></i></a>
                                </div>
                                <div class="col-md-5 col-12 order-md-2 order-1"><img src="assets/images/medical3__1_.png" class="mx-auto" alt="slide"></div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!--slide end-->
        <footer class="mastfoot mt-auto">
            <div class="inner text-center">
                <p>Made for people with <span class="text-danger">❤</span></p>
            </div>
        </footer>
    </div>
</body>
<script src="assets/js/fontawesome.min.js" crossorigin="anonymous"></script>
<script src="assets/js/jquery.min.js"></script>
<script src="assets/bootstrap/js/bootstrap.min.js"></script>

</html>