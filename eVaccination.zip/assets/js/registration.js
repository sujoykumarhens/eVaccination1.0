$(document).ready(function() {
    // Disable Mouse scrolling
    $('input[type=number]').on('mousewheel', function(e) { $(this).blur(); });
    // Disable keyboard scrolling
    $('input[type=number]').on('keydown', function(e) {
        var key = e.charCode || e.keyCode;
        // Disable Up and Down Arrows on Keyboard
        if (key == 38 || key == 40) {
            e.preventDefault();
        } else {
            return;
        }
    });

    $("#signupType").change(function() {
        $(this).find("option:selected").each(function() {
            var optionValue = $(this).attr("value");
            if (optionValue) {
                $(".userType").not("." + optionValue).hide();
                $("." + optionValue).show();
            } else {
                $(".userType").hide();
            }
        });
    }).change();
});
//patient registration validation
function formValidation() {
    var name = document.querySelector("#name").value;
    var phone = document.querySelector("#phone").value;
    var email = document.querySelector("#email").value;
    var dob = document.querySelector("#dob").value;
    var password = document.querySelector("#password").value;
    if (name_validation(name)) {
        if (phone_validation(phone)) {
            if (email_validation(email)) {
                if (dob_validation(dob)) {
                    if (password_validation(password)) {
                        return true;
                    }
                }
            }
        }
    }
    return false;
}

function formValidation1() {
    var name = document.querySelector("#hname").value;
    var phone = document.querySelector("#hphone").value;
    var email = document.querySelector("#hemail").value;
    var password = document.querySelector("#hpassword").value;
    if (name_validation(name)) {
        if (phone_validation(phone)) {
            if (email_validation(email)) {
                if (password_validation(password)) {
                    return true;
                }
            }
        }
    }
    return false;
}

function formValidation2() {
    var name = document.querySelector("#nname").value;
    var phone = document.querySelector("#nphone").value;
    var email = document.querySelector("#nemail").value;
    var password = document.querySelector("#npassword").value;
    if (name_validation(name)) {
        if (phone_validation(phone)) {
            if (email_validation(email)) {
                if (password_validation(password)) {
                    return true;
                }
            }
        }
    }
    return false;
}


// name validation
function name_validation(name) {
    var name_len = name.length;
    if (name_len == 0 || name_len < 2 || name_len > 25) {
        swal({
            title: 'Wrong Name!',
            text: 'Name should not be empty / length be between 2 to 25',
            type: 'warning',
            icon: 'error',
            timer: 4500,
            showConfirmButton: false
        }).then(function() {
            document.getElementById("name").focus();
            document.getElementById("name").scrollIntoView();
        });
        return false;
    }
    var letters = /^[A-Za-z\s]+$/;
    if (!name.match(letters)) {
        swal({
            title: 'Wrong Name!',
            text: 'Please enter a valid name. Please try again.',
            type: 'warning',
            icon: 'error',
            timer: 4500,
            showConfirmButton: false
        }).then(function() {
            document.getElementById("name").focus();
            document.getElementById("name").scrollIntoView();
        });
        return false;
    }
    return true;
}
// phone validation
function phone_validation(phone) {
    var phonee = /^[6-9]\d{9}$/;
    if (!phone.match(phonee)) {
        swal({
            title: 'Wrong Phone Number!',
            text: 'Please enter a valid phone number. Please try again.',
            type: 'warning',
            icon: 'error',
            timer: 4500,
            showConfirmButton: false
        }).then(function() {
            document.getElementById("phone").focus();
            document.getElementById("phone").scrollIntoView();
        });
        return false;
    }
    return true;
}
// email validation
function email_validation(email) {
    var atposition = email.indexOf("@");
    var dotposition = email.lastIndexOf(".");
    if (atposition < 1 || dotposition < atposition + 2 || dotposition + 2 >= email.length) {
        swal({
            title: 'Wrong Email ID!',
            text: 'Please enter a valid e-mail address. Please try again.',
            type: 'warning',
            icon: 'error',
            timer: 4500,
            showConfirmButton: false
        }).then(function() {
            document.getElementById("email").focus();
            document.getElementById("email").scrollIntoView();
        });
        return false;
    }
    return true;
}
// DOB validation
function dob_validation(dob) {
    var Bday = +new Date(dob);
    if (Bday > Date.now()) {
        swal({
            title: 'Wrong Date of Birth!',
            text: 'Birthdate can not be bigger. Please try again.',
            type: 'warning',
            icon: 'error',
            timer: 4500,
            showConfirmButton: false
        }).then(function() {
            document.getElementById("dob").focus();
            document.getElementById("dob").scrollIntoView();
        });
        return false;
    }
    var age = ~~((Date.now() - Bday) / (31557600000));
    if (age < 18) {
        swal({
            title: 'Age should not be under 18!',
            text: 'Check your age as you are under 18. Please try again.',
            type: 'warning',
            icon: 'error',
            timer: 4500,
            showConfirmButton: false
        }).then(function() {
            document.getElementById("dob").focus();
            document.getElementById("dob").scrollIntoView();
        });
        return false;
    } else if (age > 60) {
        swal({
            title: 'Age should not be above 60!',
            text: 'Check your age as you are above 60. Please try again.',
            type: 'warning',
            icon: 'error',
            timer: 4500,
            showConfirmButton: false
        }).then(function() {
            document.getElementById("dob").focus();
            document.getElementById("dob").scrollIntoView();
        });
        return false;
    }
    return true;
}
// password_validation
function password_validation(password) {
    var pass = /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)[a-zA-Z\d]{8,}$/;
    if (!password.match(pass)) {
        swal({
            title: 'Wrong Password!',
            text: 'Password must contain at least one number and one uppercase and lowercase letter, and at least 8 or more characters',
            type: 'warning',
            icon: 'error',
            timer: 4500,
            showConfirmButton: false
        }).then(function() {
            document.getElementById("password").focus();
            document.getElementById("password").scrollIntoView();
        });
        return false;
    }
    return true;
}

var passcheck = function() {
    if (document.getElementById('password').value == document.getElementById('cpassword').value) {
        document.getElementById('passmessage').style.color = 'green';
        document.getElementById('passmessage').innerHTML = 'Matching';
    } else {
        document.getElementById('passmessage').style.color = 'red';
        document.getElementById('passmessage').innerHTML = 'Not matching';
    }
}
var passcheck1 = function() {
    if (document.getElementById('hpassword').value == document.getElementById('hcpassword').value) {
        document.getElementById('passmessage1').style.color = 'green';
        document.getElementById('passmessage1').innerHTML = 'Matching';
    } else {
        document.getElementById('passmessage1').style.color = 'red';
        document.getElementById('passmessage1').innerHTML = 'Not matching';
    }
}
var passcheck2 = function() {
    if (document.getElementById('npassword').value == document.getElementById('ncpassword').value) {
        document.getElementById('passmessage2').style.color = 'green';
        document.getElementById('passmessage2').innerHTML = 'Matching';
    } else {
        document.getElementById('passmessage2').style.color = 'red';
        document.getElementById('passmessage2').innerHTML = 'Not matching';
    }
}


//login validation
function formLogin() {
    var phone = document.querySelector("#phone").value;
    if (phone_validation(phone)) {
        return true;
    }
    return false;
}

function formLogin1() {
    var phone = document.querySelector("#phone1").value;
    if (phone_validation(phone)) {
        return true;
    }
    return false;
}

function formLogin2() {
    var phone = document.querySelector("#phone2").value;
    if (phone_validation(phone)) {
        return true;
    }
    return false;
}

function formLogin3() {
    var phone = document.querySelector("#phone3").value;
    if (phone_validation(phone)) {
        return true;
    }
    return false;
}
// function forgotpassvalidation() {
//     var email = document.querySelector("#email").value;
//     var password = document.querySelector("#password").value;
//     if (email_validation(email)) {
//         if (password_validation(password)) {
//             // alert("success");
//             return true;
//         }
//     }
//     // alert("Error try again !");
//     return false;
// }