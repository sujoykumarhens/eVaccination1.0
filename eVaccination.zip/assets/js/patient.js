let sidebar = document.querySelector(".sidebar");
let closeBtn = document.querySelector("#btn");
let searchBtn = document.querySelector(".bx-search");

closeBtn.addEventListener("click", () => {
    sidebar.classList.toggle("open");
    menuBtnChange(); //calling the function(optional)
});


// following are the code to change sidebar button(optional)
function menuBtnChange() {
    if (sidebar.classList.contains("open")) {
        closeBtn.classList.replace("bx-menu", "bx-menu-alt-right"); //replacing the icons class
    } else {
        closeBtn.classList.replace("bx-menu-alt-right", "bx-menu"); //replacing the icons class
    }
}
$('#table_print').DataTable({
    dom: 'Bfrtip',
    buttons: [
        'excel', 'pdf', 'print'
    ]
});
$('#dataTable').DataTable({
    dom: 'Bfrtip',
    buttons: [
        'excel', 'pdf', 'print'
    ]
});

//clock
function showTime() {
    var date = new Date();
    var h = date.getHours(); // 0 - 23
    var m = date.getMinutes(); // 0 - 59
    var s = date.getSeconds(); // 0 - 59
    var session = "AM";

    if (h == 0) {
        h = 12;
    }

    if (h > 12) {
        h = h - 12;
        session = "PM";
    }

    h = (h < 10) ? "0" + h : h;
    m = (m < 10) ? "0" + m : m;
    s = (s < 10) ? "0" + s : s;

    var time = h + ":" + m + ":" + s + " " + session;
    document.getElementById("MyClockDisplay").innerText = time;
    document.getElementById("MyClockDisplay").textContent = time;

    setTimeout(showTime, 1000);
    var day = date.getDate();
    var month = date.getMonth() + 1;
    var year = date.getFullYear();

    if (day < 10) {
        day = '0' + day
    }
    if (month < 10) {
        month = '0' + month
    }
    const days = ["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"];
    document.getElementById("currentDate").innerHTML = day + "-" + month + "-" + year + " (" + days[date.getDay()] + ")";

}
showTime();
// $('.btn').click(function() {
//     this.disabled = true;
//     this.innerHTML = '<i class="bx bx-loader-alt bx-spin" ></i> Loading';
// });
$('.has-spiner').click(function() {
    $(this).children('.bx').addClass('bx-spin');
});

$('.slotBookngBtn').click(function() {
    $(this).hide();
    $('.slotBooking').show();
});
$('#emailTextarea').keyup(function() {
    var max = 400;
    var len = $(this).val().length;
    if (len >= max) {
        $('#text-counter').text(' you have reached the limit');
    } else {
        var char = max - len;
        $('#text-counter').text(char + ' characters left');
    }
});

$.ajax({
    url: "https://cdn-api.co-vin.in/api/v2/admin/location/states",
    method: "GET",
    dataType: "json",
    success: function(result) {
        result['states'].forEach(function(element) {
            let opt = document.createElement("option");
            opt.setAttribute("value", element['state_id']);
            opt.append(element['state_name']);
            $('#selectStateList').append(opt);
        });
    }
});

function GetDistrictDetails(state_id) {
    //   console.log(state_id);
    $.ajax({
        url: "https://cdn-api.co-vin.in/api/v2/admin/location/districts/" + state_id.toString(),
        method: "GET",
        dataType: "json",
        success: function(result) {
            $("#DistrictSelect").html('');
            $("#DistrictSelect").append('<option value="" selected disabled>Select District</option>');
            result['districts'].forEach(function(element) {
                let opt = document.createElement("option");
                opt.setAttribute("value", element['district_id']);
                opt.append(element['district_name']);
                $("#DistrictSelect").append(opt);
            });
        }
    });
}

function GetDetils(district_id) {
    // console.log(district_id);
}

//for checkin pick
$('input[name="bookingDate"]').daterangepicker({
    locale: {
        format: 'DD MMM, YYYY'
    },
    "singleDatePicker": true,
    "minYear": 2021,
    "autoApply": true,
    "startDate": moment(),
    "endDate": moment().add(3, 'days'),
    "minDate": moment().add(1, 'days'),
    "drops": "down",
});