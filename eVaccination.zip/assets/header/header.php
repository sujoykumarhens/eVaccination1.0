<!DOCTYPE html>
<html lang="en">
<head>
<meta http-equiv="content-type" content="text/html; charset=UTF-8">
<meta charset="utf-8">
<meta name="theme-color" content="#000066">
<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
<link rel="icon" href="../assets/images/logo.svg">
<title>eVaccination</title>
<?php include("../assets/links/cssLinks.php");?>
</head>
<body>