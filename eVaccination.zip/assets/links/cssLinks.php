<link rel="stylesheet" type="text/css" href="../assets/bootstrap/css/bootstrap.min.css">
<link rel="stylesheet" type="text/css" href="../assets/css/jquery.dataTables.min.css">
<link rel="stylesheet" href="https://unpkg.com/boxicons@2.0.7/css/boxicons.min.css">
<style>
    /* Chrome, Safari, Edge, Opera */
    input::-webkit-outer-spin-button,
    input::-webkit-inner-spin-button {
        -webkit-appearance: none;
        margin: 0;
    }

    /* Firefox */
    input[type=number] {
        -moz-appearance: textfield;
    }
</style>