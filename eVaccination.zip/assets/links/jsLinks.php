<script src="../assets/js/jquery.min.js"></script>
<script src="../assets/bootstrap/js/bootstrap.min.js"></script>
<script src="../assets/js/sweetalert.min.js"></script>
<!-- <script src="../assets/bootstrap/js/bootstrap.bundle.js"></script> -->

<!-- for the datatable -->
<script src="../assets/js/jquery.dataTables.min.js"></script>
<script src="../assets/js/dataTables.buttons.min.js"></script>
<script src="../assets/js/jszip.min.js"></script>
<script src="../assets/js/pdfmake.min.js"></script>
<script src="../assets/js/pdfmake.min.js"></script>
<script src="../assets/js/buttons.html5.min.js"></script>
<script src="../assets/js/buttons.print.min.js"></script>

<!-- date picker -->
<script type="text/javascript" src="https://cdn.jsdelivr.net/momentjs/latest/moment.min.js"></script>
<script type="text/javascript" src="https://cdn.jsdelivr.net/npm/daterangepicker/daterangepicker.min.js"></script>
<link rel="stylesheet" type="text/css" href="https://cdn.jsdelivr.net/npm/daterangepicker/daterangepicker.css" />
<script>
    // Disable Mouse scrolling
    $('input[type=number]').on('mousewheel', function(e) {
        $(this).blur();
    });
    // Disable keyboard scrolling
    $('input[type=number]').on('keydown', function(e) {
        var key = e.charCode || e.keyCode;
        // Disable Up and Down Arrows on Keyboard
        if (key == 38 || key == 40) {
            e.preventDefault();
        } else {
            return;
        }
    });
</script>
