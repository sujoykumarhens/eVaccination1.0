<?php
require '../config/db.php';
if (isset($_GET['nid'])) {
    $sql = "DELETE FROM `nurse` WHERE nid='".$_GET['nid']."'";
    if (mysqli_query($conn, $sql)) {
        echo "<script>alert('Nurse removed successfully');</script>";
        echo "<script>window.location.href = 'hospital.php';</script>";
        die;
    } else {
        echo "<script>alert('Sorry some  error occured');</script> ";
        echo "<script>window.location.href = 'hospital.php';</script>";
        die;
    }
}
?>