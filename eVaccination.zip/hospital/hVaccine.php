<?php
if (isset($_POST['requestVaccine'])) {
    $vid = mysqli_real_escape_string($conn, $_POST['vid']);
    $vamount = mysqli_real_escape_string($conn, $_POST['vamount']);
    $result = mysqli_query($conn, "SELECT `vid` FROM `vaccine` WHERE vid = '" . $vid . "'");
    if ($row = mysqli_fetch_array($result)) {
        date_default_timezone_set("Asia/Calcutta");
        $requestid =  date("Ymdhi");
        $sql11 = "UPDATE `hospital` SET `requestid`='" . $requestid . "',`requestamount`='" . $vamount . "',`requeststatus`='active',`requestvid`='" . $vid . "' WHERE `hphone`='" . $hphone . "'";
        if (mysqli_query($conn, $sql11)) {
            echo "<meta http-equiv='refresh' content='0'>";
            echo "<script>swal('Request generated successfully','The vaccine request generated sucessfully','success');</script>";
        } else {
            echo "<script>swal('Error','Sorry some  error occured','error');</script> ";
        }
    } else {
        echo "<script>swal('Error','No vaccine found','error');</script> ";
    }
}
?>

<h4 class="text">Hospital Dashboard</h4>

<div class="row">
    <div class="col-lg-4">
        <div class="jumbotron shadow-sm">
            <h4 class="font-weight-bold">Request for vaccine</h4>
            <div class="container-fluid">
                <form method="POST" enctype="multipart/form-data" class="needs-validation" novalidate>
                    <div class="form-row">
                        <div class="col-md-8 mb-3">
                            <label for="vaccineID">Vaccine ID</label>
                            <input type="text" class="form-control" name="vid" id="vaccineID" required>
                            <div class="valid-feedback">
                                Looks good!
                            </div>
                            <div class="invalid-feedback">
                                Please provide a valid input.
                            </div>
                        </div>
                        <div class="col-md-4 mb-3">
                            <label for="stockAmount">Need Amount</label>
                            <input type="number" class="form-control" name="vamount" id="stockAmount" required>
                            <div class="invalid-feedback">
                                Please provide a valid input.
                            </div>
                        </div>
                    </div>
                    <button class="p-2 pl-4 pr-4 border-0 btn-danger" name="requestVaccine" type="submit">Submit request</button>
                </form>
                <script>
                    // Example starter JavaScript for disabling form submissions if there are invalid fields
                    (function() {
                        'use strict';
                        window.addEventListener('load', function() {
                            // Fetch all the forms we want to apply custom Bootstrap validation styles to
                            var forms = document.getElementsByClassName('needs-validation');
                            // Loop over them and prevent submission
                            var validation = Array.prototype.filter.call(forms, function(form) {
                                form.addEventListener('submit', function(event) {
                                    if (form.checkValidity() === false) {
                                        event.preventDefault();
                                        event.stopPropagation();
                                    }
                                    form.classList.add('was-validated');
                                }, false);
                            });
                        }, false);
                    })();
                </script>
            </div>
        </div>
    </div>
    <div class="col-lg">
        <div class="jumbotron hNotifications shadow-sm">
            <h4 class="font-weight-bold">Notifications</h4>
            <div class="container-fluid requestVaccinationAlert">
                <div class="alert alert-danger alert-dismissible fade show" role="alert">
                    &emsp13;<strong> ABCD Hospital, ID : 50500</strong> has requested for <strong>100</strong> Vaccines.
                    <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="alert alert-danger alert-dismissible fade show" role="alert">
                    &emsp13;<strong> ABCD Hospital, ID : 50500</strong> has requested for <strong>100</strong> Vaccines.
                    <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- <div class="row row-cols-1 row-cols-md-2">
    <div class="col">
        <div class="jumbotron shadow-sm">
            <h4 class="font-weight-bold">Previous requests</h4>
            <table class="table  border border-danger">
                <thead class="thead">
                    <tr class="bg-danger text-white">
                        <th scope="col">#RequestID</th>
                        <th scope="col">Request for</th>
                        <th scope="col">Status</th>
                    </tr>
                </thead>
                <tbody>
                    <tr>
                        <th scope="row">1</th>
                        <td>Mark</td>
                        <td><span class="border border-success p-1 text-success"><i class='bx bx-check-double bx-tada'></i>Accepted</span></td>
                    </tr>
                    <tr>
                        <th scope="row">2</th>
                        <td>Jacob</td>
                        <td><span class="border border-success p-1 text-success"><i class='bx bx-check-double bx-tada'></i>Accepted</span></td>
                    </tr>
                    <tr>
                        <th scope="row">3</th>
                        <td>Larry</td>
                        <td><span class="border border-danger p-1 text-danger"><i class='bx bx-x bx-tada'></i>Rejected</span></td>
                    </tr>
                    <tr>
                        <th scope="row">4</th>
                        <td>Mark</td>
                        <td><span class="border border-danger p-1 text-danger"><i class='bx bx-x bx-tada'></i>Rejected</span></td>
                    </tr>
                </tbody>
            </table>
        </div>
    </div>
</div> -->

<div class="backgoundLogo"></div>