<h4 class="text">Hospital Dashboard</h4>
<div class="jumbotron shadow-sm">
    <div class="container-fluid">
        <h4 class="font-weight-bold">Patient Details</h4>
        <table class="table  border border-danger" id="dataTable">
            <thead class="thead">
                <tr class="bg-danger text-white">
                    <th scope="col">#ID</th>
                    <th scope="col">Patient Name</th>
                    <th scope="col">Contact no</th>
                    <th scope="col">Gender</th>
                    <th scope="col">Age</th>
                    <th>Vaccination Status</th>
                </tr>
            </thead>
            <tbody>
                <?php
                $patientData = mysqli_query($conn, "SELECT * FROM `patient` INNER JOIN `hospital` ON patient.hid=hospital.hid WHERE hphone='".$hphone."'");
                while ($row = mysqli_fetch_array($patientData)) {
                    $from =  new DateTime($row["pdob"]);
                    $to   = new Datetime();;
                    $page= $from->diff($to)->y;
                    echo "<tr><td>" . $row["pid"] . "</td><td>" . $row["pname"] . "</td><td>" . $row["pphone"] . "</td><td>" . $row["pgender"] . "</td><td>" . $page. "</td><td>" . $row["pvstatus"] . "</td></tr>";
                }
                ?>
            </tbody>
        </table>
    </div>
</div>