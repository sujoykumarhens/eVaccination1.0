<?php
// fetch details
$todaydate=date('Y-m-d');
$result = mysqli_query($conn, "SELECT * FROM `vdaywise` INNER JOIN `nurse` ON vdaywise.nid = nurse.nid WHERE vdate = '" . $todaydate . "'");
if ($row = mysqli_fetch_array($result)) {
    if ($row > 0) {
        $nname = $row['nname'];
        $tnid=$row['nid'];
    }
}
$patientcounter=0;
$result = mysqli_query($conn, "SELECT 'pid' FROM `patient` WHERE pvdate = '" . $todaydate . "' AND hid='".$hospitalid."'");
while ($row = mysqli_fetch_array($result)) {
    $patientcounter=$patientcounter+1;
}

if (isset($_POST['assignvaccination'])) {
    $vid = mysqli_real_escape_string($conn, $_POST['vid']);
    $vunit = mysqli_real_escape_string($conn, $_POST['vunit']);
    $nid = mysqli_real_escape_string($conn, $_POST['nid']);
    $nvdate = mysqli_real_escape_string($conn, $_POST['nvdate']);
    $searchvaccine = mysqli_query($conn, "SELECT  * FROM `hospital` WHERE `requestvid`='" . $vid . "' AND `hphone`='" . $hphone . "'");
    if ($row = mysqli_fetch_assoc($searchvaccine)) {
        $searchvaccine = mysqli_query($conn, "SELECT  * FROM `hospital` WHERE `hvstock`>'".$vunit."'");
        if ($row = mysqli_fetch_assoc($searchvaccine)) {
            $searchnurse = mysqli_query($conn, "SELECT  `nid` FROM `nurse` WHERE `nid`='".$nid."'");
            if ($row = mysqli_fetch_assoc($searchnurse)) {
                $searchdate = mysqli_query($conn, "SELECT  * FROM `vdaywise` WHERE  `vdate`='".$nvdate."' ");
                if ($row = mysqli_fetch_assoc($searchdate)) {    
                    $insertvdaywise = "INSERT INTO `vdaywise`(`nid`, `vdate`, `vid`, `vunit`) VALUES ('".$nid."','".$nvdate."','".$vid."','".$vunit."')";
                    if (mysqli_query($conn, $insertvdaywise)) {
                        echo "<meta http-equiv='refresh' content='0'>";
                        echo "<script>swal('Successful','Nurse assigned successfully','success');</script>";
                    } else {
                        echo "<script>swal('Error','Sorry some  error occured','error');</script> ";
                    }
                } else {
                    echo "<script>swal('Already assigned','Already assigned the nurse today','error');</script> ";
                }
            } else {
                echo "<script>swal('No nurse','No nurse found for this ID','error');</script> ";
            }
        } else {
            echo "<script>swal('Stock','No stock found','error');</script> ";
        }
    } else {
        echo "<script>swal('Error','No vaccine id found','error');</script> ";
    }
}
?>

<h4 class="text">Hospital Dashboard</h4>
<div class="row">
    <div class="col-lg-4">
        <div class="jumbotron shadow-sm">
            <div class="container-fluid">
                <h4 class="font-weight-bold">Assign for vaccination</h4>
                <form class="needs-validation" method="POST" enctype="multipart/form-data" novalidate>
                    <div class="form-row">
                        <div class="col-md-7 mb-3">
                            <label for="vaccineID">Vaccine ID</label>
                            <input type="text" name="vid" class="form-control" id="vaccinedid" required>
                            <div class="valid-feedback">
                                Looks good!
                            </div>
                            <div class="invalid-feedback">
                                Please provide a valid input.
                            </div>
                        </div>
                        <div class="col-md mb-3">
                            <label for="allocatedUnit">Unit Allocated</label>
                            <input type="text" name="vunit" class="form-control" id="allocatedUnit" required>
                        </div>
                        <div class="invalid-feedback">
                            Please provide a valid input.
                        </div>
                    </div>
                    <div class="form-row">
                        <div class="col-md-7 mb-3">
                            <label for="nurseID">Nurse ID</label>
                            <input type="text" name="nid" class="form-control" id="nurseID" required>
                            <div class="valid-feedback">
                                Looks good!
                            </div>
                            <div class="invalid-feedback">
                                Please provide a valid input.
                            </div>
                        </div>
                        <div class="col-md mb-3">
                            <label for="vaccineDate">Vaccine Date</label>
                            <input type="text" class="form-control" disabled name="nvdate" value="<?php echo date('Y-m-d'); ?>" id="vaccineDate" required>
                        </div>
                    </div>
                    <button class="p-2 pl-4 pr-4 border-0 btn-danger" name="assignvaccination" type="submit">Assign</button>
                </form>
                <script>
                    // Example starter JavaScript for disabling form submissions if there are invalid fields
                    (function() {
                        'use strict';
                        window.addEventListener('load', function() {
                            // Fetch all the forms we want to apply custom Bootstrap validation styles to
                            var forms = document.getElementsByClassName('needs-validation');
                            // Loop over them and prevent submission
                            var validation = Array.prototype.filter.call(forms, function(form) {
                                form.addEventListener('submit', function(event) {
                                    if (form.checkValidity() === false) {
                                        event.preventDefault();
                                        event.stopPropagation();
                                    }
                                    form.classList.add('was-validated');
                                }, false);
                            });
                        }, false);
                    })();
                </script>
            </div>
        </div>
    </div>
    <div class="col-lg">
        <div class="jumbotron shadow-sm">
            <div class="container-fluid">
                <div class="d-flex justify-content-between">
                    <h4 class="font-weight-bold">Todays' Vaccination Status</h4>
                    <div class="pl-2 pr-2 p-1 border border-danger text-danger"><i class='bx bx-time-five'></i> <span id="MyClockDisplay" class="clock" onload="showTime()"></span></div>
                </div>
                <hr />
                <ul class="list-group list-group-flush">
                    <li class="list-group-item">
                        <h5 class="font-weight-bold">Today is : <span id="textColor"><span id="currentDate"></span></span></h5>
                    </li>
                    <li class="list-group-item">
                        <h5 class="font-weight-bold">Assigned nurse : <span id="textColor"><?php echo ("$nname ($tnid)") ;?></span></h5>
                    </li>
                    <li class="list-group-item">
                        <h5 class="font-weight-bold">Vaccinated today: <span id="textColor"><?php echo $patientcounter; ?></span>&nbsp;
                            <a href="#" onClick="window.location.reload();" class="text-decoration-none text-danger has-spiner"><i class="bx  bx-border-circle bx-refresh"></i></a>
                        </h5>
                    </li>
                </ul>
            </div>
            <div class="backgoundLogo"></div>
        </div>
    </div>
</div>

<div class="jumbotron shadow-sm">
    <div class="container-fluid">
        <h4 class="font-weight-bold">Nurse Details</h4>
        <table class="table  border border-danger" id="table_print">
            <thead class="thead">
                <tr class="bg-danger text-white">
                    <th scope="col">#Nurse_ID</th>
                    <th scope="col">Nurse Name</th>
                    <th scope="col">Contact no</th>
                    <th scope="col">Action</th>
                </tr>
            </thead>
            <tbody>
                <?php
                $nursedetails = mysqli_query($conn, "SELECT * FROM `nurse`");
                while ($row = mysqli_fetch_array($nursedetails)) {
                    $nid = $row["nid"];
                    echo "<tr><td>" . $nid . "</td><td>" . $row["nname"] . "</td><td>" . $row["nphone"] . "</td><td><a href='delete.php?nid=" . $nid . "' class='border text-decoration-none text-danger border-danger p-1'><i class='bx bxs-trash-alt'></i> Delete</a></td></tr>";
                }
                ?>
            </tbody>
        </table>
    </div>
</div>