<?php 
if (isset($_POST['hnpasswordchange'])) {
    $hnpassword = mysqli_real_escape_string($conn, $_POST['hnpassword']);
    // $hnpassword = hash("sha256", $hnpassword);
    $sql = "UPDATE `hospital` SET `hpassword`='".$hnpassword."' WHERE `hphone`='".$hphone."'";
    if (mysqli_query($conn, $sql)) {
        echo "<meta http-equiv='refresh' content='0'>";
        echo "<script>swal('Successful','You have changed your details successfully','success');</script>";
    } else {
        echo "<script>swal('Error','Sorry some  error occured','error');</script> ";
    }
}
?>
<h4 class="text">Hospital Dashboard</h4>

<div class="jumbotron shadow-sm">
    <div class="container-fluid">
        <div class="d-flex justify-content-between">
            <div>
                <h2 class="font-weight-bold">Update Your Informations</h2>
                <form method="POST" enctype="multipart/form-data" class="needs-validation" novalidate>
                    <div class="form-group">
                        <input type="password" class="fadeIn fourth" name="hnpassword"  id="password" pattern="(?=.*\d)(?=.*[a-z])(?=.*[A-Z]).{8,}" title="Must contain at least one number and one uppercase and lowercase letter, and at least 8 or more characters without any special character" placeholder="New Password*" required>
                        <div class="invalid-feedback">
                            Please enter password.
                        </div>
                    </div>
                    <button type="submit" name="hnpasswordchange" class="btn btn-danger">Update</button>
                </form>
            </div>
            <div class="logobg d-none d-sm-none d-md-block"></div>
        </div>
    </div>
</div>