<h4 class="text">Patient Dashboard</h4>
<link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.10.25/css/jquery.dataTables.min.css">

<div class="jumbotron shadow-sm">
    <div class="container-fluid">
        <div class="d-flex justify-content-between">
            <div>
                <h1 class="mb-3">Welcome <strong id="textColor">Sujoy !</strong></h1>
                <p class="lead"><i class='bx bxs-smile'></i> Hope you are safe!</p>
            </div>
            <div class="logobg"></div>
        </div>
    </div>
</div>

<div class="jumbotron shadow-sm">
    <div class="container-fluid d-none">
        <div class="row">
            <div class="col-lg-9">
                <h3 class="mb-3">Your are <strong class="text-success">vaccinated !</strong></h3>
            </div>
            <div class="col-lg">
                <a href="certificate.php?s_id=1" class="btn float-right border-success text-success">
                    <img src="../assets/images/certificate.svg"> Download Certificate
                </a>
            </div>
        </div>

        <hr>
        <div class="row">
            <div class="col-lg-4">
                <ul class="list-group list-group-flush">
                    <li class="list-group-item disabled" aria-disabled="true">Personal Details</li>
                    <li class="list-group-item">Name : <strong>Sujoy Kumar Hens</strong></li>
                    <li class="list-group-item">Year of Birth : <strong>12-02-1988</strong></li>
                    <li class="list-group-item">Photo ID : <strong>Adhaar Card</strong></li>
                    <li class="list-group-item">Photo ID No : <strong>555566664444</strong></li>
                </ul>
            </div>
            <div class="col-lg">
                <ul class="list-group list-group-flush">
                    <li class="list-group-item disabled" aria-disabled="true">Vaccine Details</li>
                    <li class="list-group-item">Vaccine Name : <strong>ABCD</strong></li>
                    <li class="list-group-item">vaccinated on : <strong>12-02-1988</strong></li>
                    <li class="list-group-item">Vaccinated From : <strong>Abcd Hospital</strong></li>
                    <li class="list-group-item">Vaccinated by : <strong>Xyz Nurse</strong></li>
                </ul>
            </div>
        </div>
    </div>
    <div class="container-fluid">
        <h3 class="mb-3">Your are <strong id="textColor">not vaccinated !</strong></h3>
        <p class="lead">
            <i class='bx bxs-bulb text-danger'></i> Waiting for the last day is not a smart choice!
        </p>
        <!-- booking of slot if not booked -->
        <div class="d-none">
            <button class="btn btn-danger slotBookngBtn">Book your slot now</button>
            <div class="slotBooking" style="display:none;">

                <form class="form-row" method="POST">
                    <div class="form-group col-md-4">
                        <label for="inputState">Select State</label>
                        <select name="state" id="selectStateList" onchange="GetDistrictDetails(this.value);" class="form-control form-control-lg shadow-sm">
                            <option selected>Choose...</option>
                        </select>
                    </div>
                    <div class="form-group col-md-4">
                        <label for="inputState">Select District</label>
                        <select name="district" id="DistrictSelect" onchange="GetDetils(this.value);" class="form-control form-control-lg shadow-sm">
                            <option selected>Choose...</option>
                        </select>
                    </div>
                </form>
                <div>
                    <table class="table table-striped table-hover table-sm" id="table_print">
                        <thead>
                            <tr>
                                <th>Hospital Name</th>
                                <th>Hospital Address</th>
                                <th>Vaccine Name</th>
                                <th>Available Vaccine</th>
                                <th>Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            <tr>
                                <td>2</td>
                                <td>success</td>
                                <td>sssaaa</td>
                                <td>50</td>
                                <td><a href="#" data-toggle="modal" data-target="#newBooking" class="text-danger border border-danger pl-3 pr-3 text-decoration-none">Book Now</a></td>
                            </tr>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
        <!-- showing booked slot -->
        <div class="card bookedSlot shadow-sm border border-danger">
            <div class="card-body">
                <div class="row border-bottom">
                    <div class="col-lg">
                        <h5 class="card-title">Your Booking Details</h5>
                        <p class="card-text">Details of your vaccination</p>
                    </div>
                    <div class="col-lg">
                        <a href="appointment.php?s_id=1" class="btn float-right border-danger text-danger">
                        <i class='bx bx-printer text-danger '></i> Download Appointment Letter
                        </a>
                    </div>
                </div>
            </div>
            <div class="d-flex justify-content-between">
                <ul class="list-group list-group-flush">
                    <li class="list-group-item">Name : <strong>Sujoy Kumar Hens</strong></li>
                    <li class="list-group-item">Booking ID : <strong>542a24214</strong></li>
                    <li class="list-group-item">Date/Time : <strong>19-08-2021 11:00-12:00 ISO</strong></li>
                    <li class="list-group-item">Hospital Name : <strong>ABCD Hospital</strong></li>
                    <li class="list-group-item">Hospital Address : <strong>xxxxxxxxxx</strong></li>
                    <li class="list-group-item">ID Card No : <strong>Adhaar #202022045454</strong></li>
                </ul>
                <div>
                    <img src="https://chart.apis.google.com/chart?cht=qr&chs=200x200&chl=google.com" />
                </div>
            </div>
        </div>


    </div>
</div>