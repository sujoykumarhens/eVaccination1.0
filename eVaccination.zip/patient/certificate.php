<?php include("../assets/header/header.php"); ?>
<style type='text/css'>
    body,
    html {
        margin: 0;
        padding: 0;
    }

    body {
        color: black;
        display: table;
        font-family: Georgia, serif;
        font-size: 24px;
        text-align: center;
    }

    .container {
        background-color: whitesmoke;
        border: 20px solid firebrick;
        width: 750px;
        height: 563px;
        display: table-cell;
        vertical-align: middle;
    }

    .logo {
        color: firebrick;
    }

    .marquee {
        color: firebrick;
        font-size: 48px;
        margin: 20px;
    }

    .assignment {
        margin: 20px;
    }

    .person {
        border-bottom: 2px solid black;
        font-size: 32px;
        font-style: italic;
        margin: 20px auto;
        width: 400px;
    }

    .reason {
        margin: 20px;
    }

    .reason .d-flex p {
        font-size: 14px;
        border: none;
        background-color: whitesmoke;
        color: black;
        padding: 10px;
    }
</style>
<div class="container">
    <div class="logo">
        <img src="../assets/images/logo.svg" height="50">
        <br>eVaccination
    </div>

    <div class="marquee">
        Certificate of Vaccination
    </div>

    <div class="assignment">
        This certificate is presented to
    </div>

    <div class="person">
        Sujoy Kumar Hens
    </div>

    <div class="reason">
        <div class="d-flex justify-content-center">
            <p>Age : 18</p>
            <p>Gender : Male</p>
            <p>Id : xxxxxxxx8998</p>
        </div>
        <div class="d-flex justify-content-center">
            <p>Vaccine Name<br><strong>ABCDDD</strong></p>
            <p>Vaccinated by<br><strong>13-02-2021</strong></p>
            <p>Vaccinated at<br><strong>XYZ Hospital</strong></p>
            <p>Vaccinated By<br><strong>YYY Nurse</strong></p>
        </div>
    </div>
</div>
<?php include("../assets/footer/footer.php"); ?>
<script>
    window.onload = function() {
        window.print();
    }
</script>