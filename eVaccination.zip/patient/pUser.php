<h4 class="text">Patient Dashboard</h4>

<div class="jumbotron shadow-sm">
    <div class="container-fluid">
        <div class="d-flex justify-content-between">
            <div>
                <h2 class="font-weight-bold">Update Your Informations</h2>
                <form>
                    <div class="form-group">
                        <input type="text" class="fadeIn first" pattern="[a-zA-Z\s]+" title="Enter a valid name" name="name" id="name" placeholder="Full Name*" required autofocus>
                    </div>
                    <div class="form-group">
                        <input type="email" class="fadeIn third" id="email" pattern="[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,}$" title="Enter valid email address" name="email" placeholder="Email ID*">
                    </div>
                    <div class="form-group">
                        <input type="password" class="fadeIn fourth" id="password" pattern="(?=.*\d)(?=.*[a-z])(?=.*[A-Z]).{8,}" title="Must contain at least one number and one uppercase and lowercase letter, and at least 8 or more characters without any special character" name="New password" placeholder="New Password*" onkeyup="passcheck();" required>
                    </div>
                    <div class="form-group">
                        <input type="text" placeholder="Date of Birth*" onfocus="(this.type='date')" onblur="(this.type='text')" class="fadeIn fourth" min="1995-01-01" name="dob" id="dob" placeholder="Date of Birth*" required>
                    </div>
                    <button type="submit" class="btn btn-danger">Update</button>
                </form>
            </div>
            <div class="logobg d-none d-sm-none d-md-block"></div>
        </div>
    </div>
</div>