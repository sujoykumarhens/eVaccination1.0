<?php include("../assets/header/header.php"); ?>
<style type='text/css'>
    body,
    html {
        margin: 0;
        padding: 0;
    }

    body {
        color: black;
        display: table;
        font-family: Georgia, serif;
        font-size: 24px;
        text-align: center;
    }

    .container {
        background-color: whitesmoke;
        border: 20px solid firebrick;
        width: 750px;
        height: 700px;
        display: table-cell;
        vertical-align: middle;
    }

    .logo {
        color: firebrick;
    }

    .marquee {
        color: firebrick;
        font-size: 20px;
        margin: 20px;
    }

    .assignment {
        margin: 20px;
    }

    .person {
        border-bottom: 2px solid black;
        font-size: 32px;
        font-style: italic;
        margin: 20px auto;
        width: 400px;
    }

    .reason {
        margin: 20px;
    }

    .reason .d-flex p {
        font-size: 14px;
        border: none;
        background-color: whitesmoke;
        color: black;
        padding: 10px;
    }
</style>
<div class="container">
    <div class="logo">
        <img src="../assets/images/logo.svg" height="50">
        <br>eVaccination
    </div>

    <div class="marquee">
        Appointment Letter for Vaccination
    </div>
    <div class="person">
        Sujoy Kumar Hens
    </div>
    <div class="d-flex justify-content-center">
        <small class="text-sark mr-2 ml-2">Age : <strong>25</strong></small>
        <small class="text-sark mr-2 ml-2">Gender : <strong>Male</strong></small>
        <small class="text-sark mr-2 ml-2">Photo Id : <strong>xxxxxxxx8998</strong></small>
    </div>
    <div class="assignment text-success">
    <i class='bx bxs-badge-check' ></i> Your vaccination appointment has been confirmed.
    </div>

    <div class="reason mt-3">
        <h4 class="font-weight-bold">Appointment Details</h4>
        <div class="text-center">
            <div class="d-flex flex-column border p-3">
                <div>
                    <h6>Center : <strong>ABcccg Hospital, Arambagh, Hooghly, West Bengal</strong></h6>
                </div>

                <div class="d-flex justify-content-center">
                    <p>Vaccine Name<br><strong>ABCDDD</strong></p>
                    <p>Date<br><strong>13-02-2021</strong></p>
                    <p>ID to carry<br><strong>Adhaar Card</strong></p>
                </div>
            </div>
        </div>
    </div>
    <div class="qrprint text-center">
        <img src="https://chart.apis.google.com/chart?cht=qr&chs=100x100&chl=google.com" />
    </div>
</div>
<?php include("../assets/footer/footer.php"); ?>
<script>
    // window.onload = function() {
    //     window.print();
    // }
</script>