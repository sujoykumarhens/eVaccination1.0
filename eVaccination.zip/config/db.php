<?php
/* Database connection start */
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "evaccination";
$conn = mysqli_connect($servername, $username, $password, $dbname);
if (mysqli_connect_errno()) {
	echo ("alert('Connect failed: %s\n', mysqli_connect_error());");
	header('Location: ./');
	exit();
}
?>