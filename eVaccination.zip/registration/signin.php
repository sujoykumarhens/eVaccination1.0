<?php
require("../config/db.php");
session_start();
//login for patient
if (isset($_POST['plogin'])) {
    // personal information
    $pphone = mysqli_real_escape_string($conn, $_POST['pphone']);
    $ppassword = mysqli_real_escape_string($conn, $_POST['ppassword']);
    // $ppassword = hash("sha256", $ppassword);
    //Backend validation start
    $error = false;
    if (!preg_match("/^[0-9]{10}+$/", $pphone) || $pphone == null || $pphone == "") {
        $error = true;
        $error_type = "Invalid phone";
    }
    if (!$error) {
        $plogin = mysqli_query($conn, "SELECT * FROM `patient` WHERE pphone = '" . $pphone . "' AND ppassword = '" . $ppassword . "'");
        if ($row = mysqli_fetch_array($plogin)) {
            if(mysqli_num_rows($plogin) == 1){
                // echo "<script>alert('Successful');</script>";
                $_SESSION['pphone'] = $pphone;
                mysqli_close($conn);
                echo "<script>window.location = '../patient/patient.php';</script>";
                exit;
            }
        }
        else{
            echo "<script>alert('Wrong ID or Password');</script>";
            echo "<script>window.location = 'login.php';</script>";
            mysqli_close($conn);
            exit;
        }
    }
    else{
        echo "<script>alert('".$error_type."');</script>";
        echo "<script>window.location = 'login.php';</script>";
        mysqli_close($conn);
        exit;
    }
}
//login for hospital
if (isset($_POST['hlogin'])) {
    // personal information
    $hphone = mysqli_real_escape_string($conn, $_POST['hphone']);
    $hpassword = mysqli_real_escape_string($conn, $_POST['hpassword']);
    // $hpassword = hash("sha256", $hpassword);
    //Backend validation start
    $error = false;
    if (!preg_match("/^[0-9]{10}+$/", $hphone) || $hphone == null || $hphone == "") {
        $error = true;
        $error_type = "Invalid phone";
    }
    if (!$error) {
        $hlogin = mysqli_query($conn, "SELECT * FROM `hospital` WHERE hphone = '" . $hphone . "' AND hpassword = '" . $hpassword . "'");
        if ($row = mysqli_fetch_array($hlogin)) {
            if(mysqli_num_rows($hlogin) == 1){
                // echo "<script>alert('Successful');</script>";
                $_SESSION['hphone'] = $hphone;
                echo "<script>window.location = '../hospital/hospital.php';</script>";
                mysqli_close($conn);
                exit;
            }
        }
        else{
            echo "<script>alert('Wrong ID or password');</script>";
            echo "<script>window.location = 'login.php';</script>";
            mysqli_close($conn);
            exit;
        }
    }
    else{
        echo "<script>alert('".$error_type."');</script>";
        echo "<script>window.location = 'login.php';</script>";
        mysqli_close($conn);
        exit;
    }
}
//login for nurse
if (isset($_POST['nlogin'])) {
    // personal information
    $nphone = mysqli_real_escape_string($conn, $_POST['nphone']);
    $npassword = mysqli_real_escape_string($conn, $_POST['npassword']);
    // $npassword = hash("sha256", $npassword);
    //Backend validation start
    $error = false;
    if (!preg_match("/^[0-9]{10}+$/", $nphone) || $nphone == null || $nphone == "") {
        $error = true;
        $error_type = "Invalid phone";
    }
    if (!$error) {
        $nlogin = mysqli_query($conn, "SELECT * FROM `nurse` WHERE nphone = '" . $nphone . "' AND npassword = '" . $npassword . "'");
        if ($row = mysqli_fetch_array($nlogin)) {
            if(mysqli_num_rows($nlogin) == 1){
                // echo "<script>alert('Successful');</script>";
                $_SESSION['nphone'] = $nphone;
                mysqli_close($conn);
                echo "<script>window.location = '../nurse/nurse.php';</script>";
                exit;
            }
        }
        else{
            echo "<script>alert('Wrong ID or Password');</script>";
            echo "<script>window.location = 'login.php';</script>";
            mysqli_close($conn);
            exit;
        }
    }
    else{
        echo "<script>alert('".$error_type."');</script>";
        echo "<script>window.location = 'login.php';</script>";
        mysqli_close($conn);
        exit;
    }
}
//login for admin
if (isset($_POST['alogin'])) {
    // personal information
    $aphone = mysqli_real_escape_string($conn, $_POST['aphone']);
    $apassword = mysqli_real_escape_string($conn, $_POST['apassword']);
    // $apassword = hash("sha256", $apassword);
    //Backend validation start
    $error = false;
    if (!preg_match("/^[0-9]{10}+$/", $aphone) || $aphone == null || $aphone == "") {
        $error = true;
        $error_type = "Invalid phone";
    }
    if (!$error) {
        $alogin = mysqli_query($conn, "SELECT * FROM `admin` WHERE aphone = '" . $aphone . "' AND apassword = '" . $apassword . "'");
        if ($row = mysqli_fetch_array($alogin)) {
            if(mysqli_num_rows($alogin) == 1){
                // echo "<script>alert('Successful');</script>";
                $_SESSION['aphone'] = $aphone;
                mysqli_close($conn);
                echo "<script>window.location = '../admin/admin.php';</script>";
                exit;
            }
        }
        else{
            echo "<script>alert('Wrong ID or Password');</script>";
            echo "<script>window.location = 'login.php';</script>";
            mysqli_close($conn);
            exit;
        }
    }
    else{
        echo "<script>alert('".$error_type."');</script>";
        echo "<script>window.location = 'login.php';</script>";
        mysqli_close($conn);
        exit;
    }
}
?>