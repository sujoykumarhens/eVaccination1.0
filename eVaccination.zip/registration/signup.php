<?php include("../assets/header/header.php"); ?>
<link rel="stylesheet" type="text/css" href="../assets/css/login.css" />
<div class="container-fluid registration">
    <div class="wrapper fadeInDown">
        <div id="formContent">
            <!-- Icon -->
            <div class="fadeIn first">
                <img src="../assets/images/logo.svg" id="icon" alt="User Icon" />
                <h1 class="font-weight-bold">Registration</h1>
            </div>
            <div class="container-fluid mt-2 pb-4">
                <!-- Login Form -->
                <select class="fadeIn second" id="signupType">
                    <option>Select login type</option>
                    <option value="Patient">Patient</option>
                    <option value="Hospital">Hospital</option>
                    <option value="Nurse">Nurse</option>
                </select>
                <!-- patient info -->
                <form method="POST" action="registration.php" enctype="multipart/form-data" onsubmit="return formValidation();">
                    <div class="Patient userType" style="display:none">
                        <input type="text" class="fadeIn first" id="name" name="pname" pattern="[a-zA-Z\s]+" title="Enter a valid name" placeholder="Full Name*" required autofocus>
                        <select class="fadeIn first" required name="pgender">
                            <option selected disabled value="">Select Gender</option>
                            <option value="male">Male</option>
                            <option value="female">Female</option>
                            <option value="others">Others</option>
                        </select>
                        <input type="number" class="fadeIn second" id="phone" name="pphone" pattern="[5-9]{1}[0-9]{9}" title="Enter valid phone number" placeholder="Phone Number*" onKeyPress="if(this.value.length==10) return false;" required>
                        <input type="email" class="fadeIn third" id="email" name="pemail" pattern="[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,}$" title="Enter valid email address" placeholder="Email ID*">
                        <input type="number" class="fadeIn third" pattern="[0-9]{12}" title="Enter valid adhaar" id="aadhaar" name="paadhaar" placeholder="Aadhaar Number*" onKeyPress="if(this.value.length==12) return false;" required>
                        <input type="text" placeholder="Date of Birth*" name="pdob" id="dob" onfocus="(this.type='date')" onblur="(this.type='text')" class="fadeIn fourth" min="1995-01-01" placeholder="Date of Birth*" required>
                        <input type="password" class="fadeIn fourth" id="password" name="ppassword" placeholder="New Password*" onkeyup="passcheck();" pattern="(?=.*\d)(?=.*[a-z])(?=.*[A-Z]).{8,}" title="Must contain at least one number and one uppercase and lowercase letter, and at least 8 or more characters without any special character" required>
                        <input type="password" class="fadeIn fourth" name="cpassword" id="cpassword" placeholder="Retype Password*" onkeyup="passcheck();" pattern="(?=.*\d)(?=.*[a-z])(?=.*[A-Z]).{8,}" title="Must contain at least one number and one uppercase and lowercase letter, and at least 8 or more characters without any special character" required>
                        <p class="small" id="passmessage"></p>
                        <input type="submit" name="patientForm" class="fadeIn fourth" value="Register">
                    </div>
                </form>
                <!-- hospital info -->
                <form method="POST" action="registration.php" enctype="multipart/form-data" onsubmit="return formValidation1();">
                    <div class="Hospital userType" style="display:none">
                        <input type="text" name="hname" id="hname" class="fadeIn first" pattern="[a-zA-Z\s]+" title="Enter a valid name" placeholder="Hospital Name*" required autofocus>
                        <input type="text" id="hid" name="hid" class="fadeIn second" title="Enter Hospital ID" placeholder="Hospital ID Number*" required>
                        <input type="number" id="hphone" name="hphone" class="fadeIn second" pattern="[7-9]{1}[0-9]{9}" title="Enter valid phone number" placeholder="Phone Number*" onKeyPress="if(this.value.length==10) return false;" required>
                        <input type="email" id="hemail" name="hemail" class="fadeIn third" pattern="[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,}$" title="Enter valid email address" placeholder="Email ID">
                        <select class="fadeIn third" required name="hstate" id="selectStateList" onchange="GetDistrictDetails(this.value)">
                            <option selected disabled value="">Select State</option>
                        </select>
                        <select class="fadeIn third" name="hdistrict" id="DistrictSelect" onchange="GetDetils(this.value)">
                            <option selected disabled value="">Select District</option>
                        </select>
                        <input type="text" class="fadeIn first" name="hcity" id="city" pattern="[a-zA-Z\s]+" title="Enter a valid city name" placeholder="City Name*" required>
                        <input type="password" class="fadeIn fourth" id="hpassword" name="hpassword" pattern="(?=.*\d)(?=.*[a-z])(?=.*[A-Z]).{8,}" title="Must contain at least one number and one uppercase and lowercase letter, and at least 8 or more characters without any special character" placeholder="New Password*" onkeyup="passcheck1();" required>
                        <input type="password" class="fadeIn fourth" id="hcpassword" pattern="(?=.*\d)(?=.*[a-z])(?=.*[A-Z]).{8,}" title="Must contain at least one number and one uppercase and lowercase letter, and at least 8 or more characters without any special character" placeholder="Retype Password*" onkeyup="passcheck1();" required>
                        <p class="small" id="passmessage1"></p>
                        <input type="submit" name="hospitalForm" class="fadeIn fourth" value="Register">
                    </div>
                </form>
                <!-- nurse info -->
                <form method="POST" action="registration.php" enctype="multipart/form-data" onsubmit="return formValidation2();">
                    <div class="Nurse userType" style="display:none">
                        <input type="text" id="nname" name="nname" class="fadeIn first" pattern="[a-zA-Z\s]+" title="Enter a valid name" placeholder="Nurse Name*" required autofocus>
                        <input type="text" id="hospitalid" name="hid" class="fadeIn second" title="Enter Hospital ID" placeholder="Hospital ID Number*" required>
                        <input type="number" id="nphone" name="nphone" class="fadeIn second" pattern="[7-9]{1}[0-9]{9}" title="Enter valid phone number" placeholder="Phone Number*" onKeyPress="if(this.value.length==10) return false;" required>
                        <input type="email" id="nemail" name="nemail" class="fadeIn third" pattern="[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,}$" title="Enter valid email address" placeholder="Email ID">
                        <input type="number" id="nadhaar" name="naadhaar" class="fadeIn third" pattern="[0-9]{12}" title="Enter valid adhaar" placeholder="Adhaar Number*" onKeyPress="if(this.value.length==12) return false;" required>
                        <input type="password" class="fadeIn fourth" id="npassword" name="npassword" pattern="(?=.*\d)(?=.*[a-z])(?=.*[A-Z]).{8,}" title="Must contain at least one number and one uppercase and lowercase letter, and at least 8 or more characters without any special character" placeholder="New Password*" onkeyup="passcheck2();" required>
                        <input type="password" class="fadeIn fourth" id="ncpassword" pattern="(?=.*\d)(?=.*[a-z])(?=.*[A-Z]).{8,}" title="Must contain at least one number and one uppercase and lowercase letter, and at least 8 or more characters without any special character" placeholder="Retype Password*" onkeyup="passcheck2();" required>
                        <p class="small" id="passmessage2"></p>
                        <input type="submit" class="fadeIn fourth" name="nurseForm" value="Register">
                    </div>
                </form>
            </div>
            <!-- Remind Passowrd -->
            <div id="formFooter">
                Already registred? <a class="underlineHover" href="login.php">Login here</a>
            </div>

        </div>
    </div>
</div>

<?php include("../assets/footer/footer.php"); ?>
<script type="text/javascript" src="../assets/js/registration.js"></script>

<script>
    $.ajax({
        url: "https://cdn-api.co-vin.in/api/v2/admin/location/states",
        method: "GET",
        dataType: "json",
        success: function(result) {
            result['states'].forEach(function(element) {
                let opt = document.createElement("option");
                opt.setAttribute("value", element['state_id']);
                opt.append(element['state_name']);
                $('#selectStateList').append(opt);
            });
        }
    });

    function GetDistrictDetails(state_id) {
        //   console.log(state_id);
        $.ajax({
            url: "https://cdn-api.co-vin.in/api/v2/admin/location/districts/" + state_id.toString(),
            method: "GET",
            dataType: "json",
            success: function(result) {
                $("#DistrictSelect").html('');
                $("#DistrictSelect").append('<option value="" selected disabled>Select District</option>');
                result['districts'].forEach(function(element) {
                    let opt = document.createElement("option");
                    opt.setAttribute("value", element['district_id']);
                    opt.append(element['district_name']);
                    $("#DistrictSelect").append(opt);
                });
            }
        });
    }

    function GetDetils(district_id) {
        // console.log(district_id);
    }
</script>