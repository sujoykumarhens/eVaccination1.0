<?php
require("../config/db.php");
session_start();
//patient registration
if (isset($_POST['patientForm'])) {
    // personal information
    $pname = mysqli_real_escape_string($conn, $_POST['pname']);
    $pgender = mysqli_real_escape_string($conn, $_POST['pgender']);
    $pphone = mysqli_real_escape_string($conn, $_POST['pphone']);
    $pemail = mysqli_real_escape_string($conn, $_POST['pemail']);
    $paadhaar = mysqli_real_escape_string($conn, $_POST['paadhaar']);
    $pdob = mysqli_real_escape_string($conn, $_POST['pdob']);
    $ppassword = mysqli_real_escape_string($conn, $_POST['ppassword']);
    $ppassword = hash("sha256", $ppassword);
    $pid = $pname . "_" . $pphone;
    // check registered or not
    $result = mysqli_query($conn, "SELECT `pphone` FROM `patient` WHERE pphone = '" . $pphone . "'");
    if ($row = mysqli_fetch_array($result)) {
        echo "<script>alert('Already Registered. Please try again or contact admin');</script>";
        mysqli_close($conn);
        echo "<script>window.location = 'signup.php';</script>";
        exit;
    }
    //Backend validation start
    $error = false;
    if (!preg_match("/^[a-zA-Z ]+$/", $pname) || $pname == "" || $pname == null) {
        $error = true;
        $error_type = "Candidate name must contain only alphabets and space";
    } elseif (!preg_match("/^([0-9]{4})\-([0-9]{2})\-([0-9]{2})$/", $pdob) || $pdob == null || $pdob == "") {
        $error = true;
        $error_type = "Invalid Date of Birth";
    } elseif (!preg_match("/^[a-zA-Z ]+$/", $pgender) || $pgender == null || $pgender == "") {
        $error = true;
        $error_type = "Invalid Gender";
    } elseif (!preg_match("/^[0-9]{10}+$/", $pphone) || $pphone == null || $pphone == "") {
        $error = true;
        $error_type = "Invalid phone";
    }
    //insert into the database start
    if (!$error) {
        if (mysqli_query($conn, "INSERT INTO `patient`(`pid`, `pname`,`pgender`, `pphone`, `pemail`, `paadhaar`, `pdob`, `ppassword`) VALUES ('" . $pid . "','" . $pname . "','" . $pgender . "','" . $pphone . "','" . $pemail . "','" . $paadhaar . "','" . $pdob . "','" . $ppassword . "')")) {
            $_SESSION['pid'] = $pid;
            echo "<script>alert('Successfully registered. We are taking you to the dashboard.');</script>";
            echo "<script>window.location = '../patient/patient.php';</script>";
        } else {
            echo "<script>alert('Error occured '$error);</script>";
            mysqli_close($conn);
            echo "<script>window.location = 'signup.php';</script>";
            die;
        }
    }
    else{
        echo "<script>alert('".$error_type."')</script>";
    }
}
//hospital registration
if (isset($_POST['hospitalForm'])) {
    // personal information
    $hname = mysqli_real_escape_string($conn, $_POST['hname']);
    $hid = mysqli_real_escape_string($conn, $_POST['hid']);
    $hphone = mysqli_real_escape_string($conn, $_POST['hphone']);
    $hemail = mysqli_real_escape_string($conn, $_POST['hemail']);
    $hstate = mysqli_real_escape_string($conn, $_POST['hstate']);
    $hcity = mysqli_real_escape_string($conn, $_POST['hcity']);
    $hdistrict = mysqli_real_escape_string($conn, $_POST['hdistrict']);
    $hpassword = mysqli_real_escape_string($conn, $_POST['hpassword']);
    // $hpassword = hash("sha256", $hpassword);
    // check registered or not
    $result = mysqli_query($conn, "SELECT `hphone` FROM `hospital` WHERE hphone = '" . $hphone . "'");
    if ($row = mysqli_fetch_array($result)) {
        echo "<script>alert('Already Registered. Please try again or contact admin');</script>";
        mysqli_close($conn);
        echo "<script>window.location = 'signup.php';</script>";
        exit;
    }
    //Backend validation start
    $error = false;
    if (!preg_match("/^[a-zA-Z ]+$/", $hname) || $hname == "" || $hname == null) {
        $error = true;
        $error_type = "Candidate name must contain only alphabets and space";
    } elseif (!preg_match("/^[0-9]{10}+$/", $hphone) || $hphone == null || $hphone == "") {
        $error = true;
        $error_type = "Invalid phone";
    }
    $hvstock=0;
    //insert into the database start
    if (!$error) {
        if (mysqli_query($conn, "INSERT INTO `hospital`(`hid`, `hname`, `hphone`, `hemail`, `hstate`, `hdistrict`, `hcity`, `hpassword`,`hvstock`) VALUES ('" . $hid . "','" . $hname . "','" . $hphone . "','" . $hemail . "','" . $hstate . "','" . $hdistrict . "','" . $hcity . "','" . $hpassword . "','" . $hvstock . "')")) {
            $_SESSION['hid'] = $hid;
            echo "<script>alert('Successfully registered. We are taking you to the dashboard.');</script>";
            echo "<script>window.location = '../hospital/hospital.php';</script>";
        } else {
            echo "<script>alert('Error occured');</script>";
            mysqli_close($conn);
            echo "<script>window.location = 'signup.php';</script>";
            die;
        }
    } else{
        echo "<script>alert('".$error_type."')</script>";
    }
}

//nurse registration
if (isset($_POST['nurseForm'])) {
    // personal information
    $nname = mysqli_real_escape_string($conn, $_POST['nname']);
    $hid = mysqli_real_escape_string($conn, $_POST['hid']);
    $nphone = mysqli_real_escape_string($conn, $_POST['nphone']);
    $nemail = mysqli_real_escape_string($conn, $_POST['nemail']);
    $naadhaar = mysqli_real_escape_string($conn, $_POST['naadhaar']);
    $npassword = mysqli_real_escape_string($conn, $_POST['npassword']);
    $npassword = hash("sha256", $npassword);
    $nid = $nname . "_" . $nphone;
    // check registered or not
    $result3 = mysqli_query($conn, "SELECT `nphone` FROM `nurse` WHERE nphone = '" . $nphone . "'");
    if ($row3 = mysqli_fetch_array($result3)) {
        echo "<script>alert('Phone number already Registered. Please try again or contact admin');</script>";
        mysqli_close($conn);
        echo "<script>window.location = 'signup.php';</script>";
        exit;
    }
    $result = mysqli_query($conn, "SELECT `hid` FROM `hospital` WHERE hid = '" . $hid . "'");
    if ($row = mysqli_fetch_array($result)) {
        $result2 = mysqli_query($conn, "SELECT `pid` FROM `nurse` WHERE pid = '" . $pid . "'");
        if ($row2 = mysqli_fetch_array($result2)) {
            echo "<script>alert('Already Registered. Please try again or contact admin');</script>";
            mysqli_close($conn);
            echo "<script>window.location = 'signup.php';</script>";
            exit;
        }
    } else {
        echo "<script>alert('No hospital found for this id');</script>";
        mysqli_close($conn);
        echo "<script>window.location = 'signup.php';</script>";
        exit;
    }
    //Backend validation start
    $error = false;
    if (!preg_match("/^[a-zA-Z ]+$/", $nname) || $nname == "" || $nname == null) {
        $error = true;
        $error_type = "Candidate name must contain only alphabets and space";
    } elseif (!preg_match("/^[0-9]{10}+$/", $nphone) || $nphone == null || $nphone == "") {
        $error = true;
        $error_type = "Invalid phone";
    }
    //insert into the database start
    if (!$error) {
        if (mysqli_query($conn, "INSERT INTO `nurse`(`nid`, `nname`, `nphone`, `nemail`, `naadhaar`, `npassword`, `hid`) VALUES ('" . $nid . "','" . $nname . "','" . $nphone . "','" . $nemail . "','" . $naadhaar . "','" . $npassword . "','" . $hid . "')")) {
            $_SESSION['nid'] = $nid;
            echo "<script>alert('Successfully registered. We are taking you to the dashboard.');</script>";
            echo "<script>window.location = '../nurse/nurse.php';</script>";
        } else {
            echo "<script>alert('Error occured '$error);</script>";
            mysqli_close($conn);
            echo "<script>window.location = 'signup.php';</script>";
            die;
        }
    } else{
        echo "<script>alert('".$error_type."')</script>";
    }
}
?>
