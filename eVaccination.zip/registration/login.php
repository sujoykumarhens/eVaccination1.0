<?php
session_start();
// Check user login or not
if (isset($_SESSION['pphone'])) {
    header('Location: ../petient/petient.php');
}
// Check user login or not
if (isset($_SESSION['nphone'])) {
    header('Location: ../nurse/nurse.php');
}
// Check user login or not
if (isset($_SESSION['hphone'])) {
    header('Location: ../hospital/hospital.php');
}
// Check user login or not
if (isset($_SESSION['aphone'])) {
    header('Location: ../admin/admin.php');
}
include("../assets/header/header.php");
?>
<link rel="stylesheet" type="text/css" href="../assets/css/login.css" />
<div class="container-fluid">
    <div class="wrapper fadeInDown">
        <div id="formContent">
            <!-- Tabs Titles -->

            <!-- Icon -->
            <div class="fadeIn first">
                <img src="../assets/images/logo.svg" id="icon" alt="User Icon" />
                <h1 class="font-weight-bold">Login</h1>
            </div>
            <div class="container-fluid mt-2 pb-4">
                <!-- Login Form -->

                <select class="fadeIn second" id="signupType" name="loginType">
                    <option>Select login type</option>
                    <option value="Patient">Patient</option>
                    <option value="Hospital">Hospital</option>
                    <option value="Nurse">Nurse</option>
                    <option value="Admin">Admin</option>
                </select>
                <form action="signin.php" enctype="multipart/form-data" method="POST" class="form-horizontal" role="form" onsubmit="return formLogin();">
                    <div class="Patient userType" style="display:none">
                        <input type="number" id="phone" name="pphone" class="fadeIn  second" pattern="[6-9]{1}[0-9]{9}" onKeyPress="if(this.value.length==10) return false;" placeholder="registered mobile no" required>
                        <input type="password" id="password" name="ppassword" class="fadeIn  third" placeholder="password" required>
                        <input type="submit" class="fadeIn fourth" name="plogin" value="Log In">
                    </div>
                </form>
                <form action="signin.php" enctype="multipart/form-data" method="POST" class="form-horizontal" role="form" onsubmit="return formLogin1();">
                    <div class="Hospital userType" style="display:none">
                        <input type="number" id="phone1" name="hphone" pattern="[6-9]{1}[0-9]{9}" class="fadeIn  second" onKeyPress="if(this.value.length==10) return false;" placeholder="registered mobile no" required>
                        <input type="password" id="password1" name="hpassword" class="fadeIn  third" placeholder="password" required>
                        <input type="submit" class="fadeIn fourth" name="hlogin" value="Log In">
                    </div>
                </form>
                <form action="signin.php" enctype="multipart/form-data" method="POST" class="form-horizontal" role="form" onsubmit="return formLogin2();">
                    <div class="Nurse userType" style="display:none">
                        <input type="number" pattern="[6-9]{1}[0-9]{9}" id="phone2" name="nphone" class="fadeIn  second" onKeyPress="if(this.value.length==10) return false;" placeholder="registered mobile no" required>
                        <input type="password" id="password2" class="fadeIn  third" name="npassword" placeholder="password">
                        <input type="submit" class="fadeIn fourth" name="nlogin" value="Log In">
                    </div>
                </form>
                <form action="signin.php" enctype="multipart/form-data" method="POST" class="form-horizontal" role="form" onsubmit="return formLogin3();">
                    <div class="Admin userType" style="display:none">
                        <input type="number" id="phone3" name="aphone" pattern="[6-9]{1}[0-9]{9}" class="fadeIn  second" onKeyPress="if(this.value.length==10) return false;" placeholder="registered mobile no" required>
                        <input type="password" id="password3" name="apassword" class="fadeIn third" placeholder="password">
                        <input type="submit" class="fadeIn fourth" name="alogin" value="Log In">
                    </div>
                </form>
            </div>
            <!-- Remind Passowrd -->
            <div id="formFooter">
                Not registred? <a class="underlineHover" href="signup.php">Signup here</a>
            </div>

        </div>
    </div>
</div>
<?php include("../assets/footer/footer.php"); ?>
<script type="text/javascript" src="../assets/js/registration.js"></script>